# beautiful_list

A new Flutter project.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).

## setting up
View tutorial online
[Medium](https://medium.com/@afegbua/this-is-the-second-part-of-the-beautiful-list-ui-and-detail-page-article-ecb43e203915).


```dart

cd beautiful-list
flutter packages get
open -a simulator
flutter run

```
