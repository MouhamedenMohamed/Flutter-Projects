package com.ketanchoyal.our_e_school

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
