import 'package:flutter/material.dart';
import 'package:meAccounting/src/app.dart';

void main() {
  /*
  * main function just runs the app! 
  */
  runApp(App());
}