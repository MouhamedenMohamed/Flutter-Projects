import 'package:flutter/material.dart';
import 'package:flutter_wallet_ui_challenge/src/app.dart';

void main() => runApp(App());




