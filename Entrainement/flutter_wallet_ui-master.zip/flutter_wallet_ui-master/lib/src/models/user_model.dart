class UserModel{
  String _name,_profilePic;

  UserModel(this._name, this._profilePic);

  String get name => _name;

  get profilePic => _profilePic;

}