# flutter_wallet_ui_challenge

A new Flutter project.

Project Demo Video : https://www.youtube.com/watch?v=Vyj65qh_QiA

## Getting Started
Flutter Wallet UI Challange
  
  Page Name | Pictures   
 --- | --- 
 [Wallet Home Page] | <img src="screens/homepage.png" height= "800"/>
 [Overview Page] | <img src="screens/overviewpage.png" height= "800"/>
