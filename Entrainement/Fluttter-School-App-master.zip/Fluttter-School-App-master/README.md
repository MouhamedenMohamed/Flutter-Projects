# Fluttter-School-App
A School App based on Flutter Framework.
mail us: skybirdwebmedia@gmail.com
Demo(Dead):
[https://play.google.com/store/apps/details?id=com.bpsplayschool.app&hl=en](https://play.google.com/store/apps/details?id=com.bpsplayschool.app&hl=en).

<img src="https://github.com/strbbrn/Fluttter-School-App/raw/master/Screenshot_2019-07-06-16-09-56-465_com.bpsplayschool.app.png" width="30%"></img> <img src="https://github.com/strbbrn/Fluttter-School-App/raw/master/Screenshot_2019-07-06-16-10-02-448_com.bpsplayschool.app.png" width="30%"></img> <img src="https://github.com/strbbrn/Fluttter-School-App/raw/master/Screenshot_2019-07-06-16-10-05-763_com.bpsplayschool.app.png" width="30%"></img> 

## 🌴 License
**MIT**

**You are welcome to use this however you wish within the MIT license, but please retain my credentials and links back to this repo.**
