class PurchaseVoucher {

  final String date;
  final String partyname;
  final int amount;
  final String masterid;
  final String iscancelled;

  PurchaseVoucher({this.date, this.partyname, this.amount, this.masterid, this.iscancelled});
}