

class Production {

  final DateTime date;
  final String product;
  final String production;

  Production({this.date, this.product, this.production});
}