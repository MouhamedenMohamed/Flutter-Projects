
class Khata {

  final DateTime date;
  final String partyname;
  final String amount;
  final String trantype;
  final String id;

  Khata({this. id, this.date, this.partyname, this.amount, this.trantype});
}