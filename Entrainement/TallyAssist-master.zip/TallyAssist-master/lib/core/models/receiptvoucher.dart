class ReceiptVoucher {

  final String date;
  final String partyname;
  final int amount;
  final String masterid;
  final String iscancelled;

  ReceiptVoucher({this.date, this.partyname, this.amount, this.masterid, this.iscancelled});
}