
class Metrics {

  final String totalSales;
  final String totalPurchases;

  Metrics({this.totalSales, this.totalPurchases});
}