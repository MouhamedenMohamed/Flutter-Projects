class PaymentVoucher {

  final String date;
  final String partyname;
  final double amount;
  final String masterid;
  final String iscancelled;

  PaymentVoucher({this.date, this.partyname, this.amount, this.masterid, this.iscancelled});
}