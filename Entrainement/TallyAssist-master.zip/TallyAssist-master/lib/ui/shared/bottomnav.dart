// import 'package:flutter/material.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// BottomNavigationBar bottomNav(_selectedPage) {
//   return BottomNavigationBar(
//     currentIndex: _selectedPage,
//     type: BottomNavigationBarType.fixed,
//     onTap: (int index) {
//       setState(() {
//         _selectedPage = index;
//       });
//     },
//     items: const <BottomNavigationBarItem>[
//       BottomNavigationBarItem(
//         icon: Icon(FontAwesomeIcons.tachometerAlt),
//         title: Text('MyReport'),
//       ),
//       BottomNavigationBarItem(
//         icon: Icon(FontAwesomeIcons.building),
//         title: Text('Party'),
//       ),
//       BottomNavigationBarItem(
//         icon: Icon(FontAwesomeIcons.book),
//         title: Text('Khata'),
//       ),
//       BottomNavigationBarItem(
//         icon: Icon(FontAwesomeIcons.warehouse),
//         title: Text('Stock'),
//       ),
//       BottomNavigationBarItem(
//         icon: Icon(FontAwesomeIcons.ellipsisH),
//         title: Text('More'),
//       ),
//     ],
//     // currentIndex: _selectedIndex,
//     // selectedItemColor: Colors.amber[800],
//     // onTap: _onItemTapped,
//   );
// }
