import 'package:flutter/material.dart';
import 'package:user_profile_settings_app/bloc/drawer_bloc.dart';

class NotificationScreen extends StatelessWidget with DrawerStates{
  @override
  Widget build(BuildContext context) {
    return Container(

    );
  }
}
