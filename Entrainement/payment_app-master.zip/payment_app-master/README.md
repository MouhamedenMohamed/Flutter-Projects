# payment_app
This is a simple project that will help you learn how to build a simple payment app using Flutter and Flutterwave.

You can read an article about this project, which is on medium: https://medium.com/flutter-community/build-a-simple-payment-platform-in-10-minutes-using-flutter-and-flutterwave-97e8c8ad02ff

<img src="https://miro.medium.com/max/2774/1*ibuZ9_KxadJELUVZv96Wvw.jpeg"  title="payment_app">

Contact - Let's become friends

<a href="https://twitter.com/Promise_Amadi1">Twitter</a></br>
<a href="https://github.com/Wizpna">Github</a></br>
<a href="https://www.linkedin.com/in/promise-amadi-101759a1/">Linkedin</a></br>
<a href="https://www.facebook.com/promise.nzubechi.amadi">Facebook</a>

