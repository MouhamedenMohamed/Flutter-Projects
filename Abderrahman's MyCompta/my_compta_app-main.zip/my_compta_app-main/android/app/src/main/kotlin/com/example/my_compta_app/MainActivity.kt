package com.example.my_compta_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
