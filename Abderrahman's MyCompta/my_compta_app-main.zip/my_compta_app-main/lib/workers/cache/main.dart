import 'hive/main.dart';

initCacheWorkers() async {
  await initHive();
}
