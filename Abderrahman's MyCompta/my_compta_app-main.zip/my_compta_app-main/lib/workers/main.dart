import 'cache/main.dart';

initWorders() async {
  await initCacheWorkers();
}
